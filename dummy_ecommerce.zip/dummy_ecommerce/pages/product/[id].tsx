import { GetServerSideProps } from "next";
import { useContext } from "react";
import { CartContext } from "../../context/CartContext";
import { Product } from "../../types/product";

export default function ProductDetail({ product }: { product: Product }) {
  const { add } = useContext(CartContext);

  if (!product) return <p className="p-4">Produk tidak ditemukan.</p>;

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row gap-6">
        <img src={product.images[0]} alt={product.title} className="w-full md:w-1/2 rounded-lg" />
        <div>
          <h2 className="text-2xl font-bold">{product.title}</h2>
          <p className="text-gray-600">{product.category}</p>
          <p className="text-lg font-semibold mt-2 text-blue-700">${product.price}</p>
          <p className="text-sm mt-2">{product.description}</p>
          <p className="text-sm mt-2 text-yellow-500">
            ⭐ {product.rating.rate} ({product.rating.count})
          </p>
          <button
            className="mt-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
            onClick={() => add({ product, qty: 1 })}
          >
            Tambahkan ke Keranjang
          </button>
        </div>
      </div>
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async ({ params }) => {
  const res = await fetch(`https://dummyjson.com/products/${params?.id}`);
  if (!res.ok) return { notFound: true };
  const product = await res.json();
  return {
    props: { product },
  };
};
